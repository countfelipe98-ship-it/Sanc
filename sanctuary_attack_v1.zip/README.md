# 

## ️ Funções
- **Iniciar Bot**: Inicia o bot e mostra estatísticas em tempo real.
- **Editar Token**: Altera o token do bot salvo.
- **Informações Gerais**: Detalhes sobre o sistema e links oficiais.
- **Arquivos e Pastas**: Visualização da estrutura do projeto.

##  Estrutura de Comandos
Todos os comandos do bot devem ser colocados na pasta `commands/`. O painel carrega automaticamente qualquer arquivo `.py` nesta pasta.

---
**Link Oficial:** [Cyber Attack](https://cyber-attack-092.my.canva.site/)
