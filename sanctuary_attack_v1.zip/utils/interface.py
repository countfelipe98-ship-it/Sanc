import os
import sys
from colorama import init, Fore, Style

init(autoreset=True)

# Definição de tons de vermelho para um degradê (256 cores)
# 52: Vermelho Escuro, 88: Bordô, 160: Vermelho Vivo, 196: Vermelho Claro, 255: Branco
GRADIENT_COLORS = [52, 88, 160, 196, 255, 196, 160, 88, 52]

RED = "\033[38;5;196m"
WHITE = "\033[38;5;255m"
RESET = Style.RESET_ALL

NEW_ASCII_ART = """ ▄████▄   ▄▄▄       ███▄    █  ▄████▄  
▒██▀ ▀█  ▒████▄     ██ ▀█   █ ▒██▀ ▀█  
▒▓█    ▄ ▒██  ▀█▄  ▓██  ▀█ ██▒▒▓█    ▄ 
▒▓▓▄ ▄██▒░██▄▄▄▄██ ▓██▒  ▐▌██▒▒▓▓▄ ▄██▒
▒ ▓███▀ ░ ▓█   ▓██▒▒██░   ▓██░▒ ▓███▀ ░
░ ░▒ ▒  ░ ▒▒   ▓▒█░░ ▒░   ▒ ▒ ░ ░▒ ▒  ░
  ░  ▒     ▒   ▒▒ ░░ ░░   ░ ▒░  ░  ▒   
░          ░   ▒      ░   ░ ░ ░        
░ ░            ░  ░         ░ ░ ░      
░                             ░        

▄▄▄█████▓ █    ██  ▄▄▄       ██▀███   ▓██   ██▓
▓  ██▒ ▓▒ ██  ▓██▒▒████▄    ▓██ ▒ ██▒  ▒██  ██▒
▒ ▓██░ ▒░▓██  ▒██░▒██  ▀█▄  ▓██ ░▄█ ▒   ▒██ ██░
░ ▓██▓ ░ ▓▓█  ░██░░██▄▄▄▄██ ▒██▀▀█▄     ░ ▐██▓░
  ▒██▒ ░ ▒▒█████▓ ░▓█   ▓██▒░██▓ ▒██▒   ░ ██▒▓░
  ▒ ░░   ░▒▓▒ ▒ ▒ ░▒▒   ▓▒█░░ ▒▓ ░▒▓░    ██▒▒▒ 
    ░    ░░▒░ ░ ░  ▒   ▒▒ ░  ░▒ ░ ▒░  ▓██ ░▒░ 
  ░       ░░░ ░ ░  ░   ▒     ░░   ░   ▒ ▒ ░░  
            ░          ░  ░   ░       ░ ░     
                                      ░ ░           
"""

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def get_color_escape(color_code):
    return f"\033[38;5;{color_code}m"

def print_gradient_ascii():
    lines = NEW_ASCII_ART.strip('\n').split('\n')
    
    for line in lines:
        colored_line = ""
        line_len = len(line)
        if line_len == 0:
            print("")
            continue
            
        for i, char in enumerate(line):
            # Calcula o índice da cor baseado na posição horizontal (i)
            color_idx = int((i / line_len) * (len(GRADIENT_COLORS) - 1))
            color_code = GRADIENT_COLORS[color_idx]
            colored_line += f"{get_color_escape(color_code)}{char}"
        
        print(colored_line)
    
    # Texto final com cores atualizadas para Vermelho e Branco
    print(f"\n{RED}painel v1 sanctuary: {WHITE}https://discord.gg/eauHuCd3h{RESET}\n")

def wait_enter():
    input(f"\n{RED}Pressione Enter para voltar ao início...{RESET}")

# Se quiser testar direto:
if __name__ == "__main__":
    clear_screen()
    print_gradient_ascii()
